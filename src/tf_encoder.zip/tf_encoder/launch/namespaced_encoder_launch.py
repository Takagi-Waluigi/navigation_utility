from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='tf_encoder',
            namespace='robot1',
            executable='map_converter',
            remappings=[('/tf','tf'), ('/tf_static','tf_static'),],
        ),

        Node(
            package='tf_encoder',
            namespace='robot1',
            executable='odom_converter',
            remappings=[('/tf','tf'), ('/tf_static','tf_static'),],
        ),

        # Node(
        #     package='tf_encoder',
        #     namespace='framelight3',
        #     executable='map_converter',
        #     remappings=[('/tf','tf'), ('/tf_static','tf_static'),],
        # ),

        # Node(
        #     package='tf_encoder',
        #     namespace='framelight3',
        #     executable='odom_converter',
        #     remappings=[('/tf','tf'), ('/tf_static','tf_static'),],
        # ),

        # Node(
        #     package='tf_encoder',
        #     executable='sender',
        #     #namespace='robot1',
        #     remappings=[('/tf','robot1/tf')],
        # ),
        
    ])